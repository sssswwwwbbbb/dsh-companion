# 芽音 · 工程说明

## 环境

- macOS，Python 3（Pillow、numpy、scipy）
- 图标与界面全部程序化绘制，无设计软件依赖
- 视频编码：Swift + AVFoundation（本机无 ffmpeg）

## 目录

- `source/icons/` — 56 枚 SVG 源稿（24×24 画板，线宽 2.0）
- `source/icons/_generator/gen_icons.py` — 图标生成器；`PALETTES` 定义 accent / neutral 两套配色，`override` 指定 send/stop 为纯白。调用：`python3 gen_icons.py <包根> <accent|neutral>`
- `source/ref/` — 4 张手绘设定原图 + 主视觉源图

## 复现要点

1. **图标**：24 画板 → 32× 超采样 → 96 px RGBA；每组 56 枚，四套配色（light / dark / light-neutral / dark-neutral）
2. **徽记**：缺口外环 + 内环 + 左右两个小发圈 + 中心星芒，导出 96×96 浅深两版
3. **状态三时刻帧**：6 态 × 3 时刻（initial / active / settled）× 明暗 = 36 枚
4. **待机循环**：48 帧，正弦呼吸 + 绕环光点，首尾同帧；`frames` 工具以 24 fps 编码为 2.00 s MP4
5. **开场正片**：无文字主视觉底图按 0→10 s 推拉曲线裁切重采样，叠加亮度曲线（0.80→1.02→1.10）与 3.70–4.90 s 斜向扫描光带；9.60 s 起与落版帧交叉淡入；帧序列 24 fps 编码后与 `opening-mix-10.5.wav` 封装
6. **音频**：`aud.py` 提供 24-bit LE 读写、`resample_poly` 重采样、`norm_rms`、`fade_edges`；台词干声来自合成音色，`_wet` 版为 7200 Hz 低通 + Schroeder 轻空腔（wet 0.20 / room 0.026）

## 依赖说明

- 生成脚本依赖本机 Pillow / numpy / scipy，未随包分发脚本本体之外的二进制
- 视频封装依赖系统 AVFoundation，无外部 CLI 依赖
