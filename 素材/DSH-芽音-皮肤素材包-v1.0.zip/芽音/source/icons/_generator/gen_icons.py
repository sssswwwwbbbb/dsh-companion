# -*- coding: utf-8 -*-
"""按功能位生成 24x24 线性矢量图标：同一份几何定义输出 SVG + 96x96 RGBA PNG(浅/深)。"""
import os, math
from PIL import Image, ImageDraw

G = 24.0          # 画板
STROKE = 2.0      # 线宽(24 画板)
SUPER = 32        # 超采样倍数 -> 768x768
OUT_PX = 96

LIGHT_COLOR = (0xC0, 0x28, 0x2E)   # --accent 浅色模式
DARK_COLOR = (0xFF, 0x6A, 0x3C)    # --accent 深色模式

# ---- 图元 ----
def L(x1, y1, x2, y2): return ("line", x1, y1, x2, y2)
def P(pts, closed=False): return ("poly", pts, closed)
def R(x0, y0, x1, y1, r=0, fill=False): return ("rect", x0, y0, x1, y1, r, fill)
def C(cx, cy, r, fill=False): return ("circle", cx, cy, r, fill)
def A(cx, cy, rx, ry, start, end): return ("arc", cx, cy, rx, ry, start, end)
def FP(pts): return ("fillpoly", pts)

def arcarrow(cx, cy, r, start, end):
    return ("arcarrow", cx, cy, r, start, end)

def arc_points(cx, cy, rx, ry, start, end, step=5.0):
    """PIL 角度约定：0=三点方向，顺时针。"""
    n = max(2, int(abs(end - start) / step) + 1)
    pts = []
    for i in range(n + 1):
        a = math.radians(start + (end - start) * i / n)
        pts.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
    return pts

# ---- 56 个功能位 ----
NAV = {
"workspace": [R(3,4,21,20,2), L(9,4,9,20), L(12,8,18,8), L(12,12,18,12)],
"compose":   [R(3,4,17,20,2), L(6,9,14,9), L(6,13,11,13), L(14,19,20,12), L(20,12,21,11), L(13,18,14,17)],
"conversation": [R(3,5,21,16,3), P([(8,16),(8,20),(12,16)])],
"history":   [C(12,12,7), L(12,12,12,7), L(12,12,16,14), P([(5.5,9.5),(4,9.5),(4,8)])],
"search":    [C(10.5,10.5,5.5), L(14.5,14.5,20,20)],
"panel-left":[R(3,4,21,20,2), L(9,4,9,20), L(5,8,7,8), L(5,12,7,12), L(5,16,7,16)],
"folder":    [P([(3,8),(3,5),(9,5),(11,8)]), R(3,8,21,19,2)],
"folder-open":[P([(3,5),(9,5),(11,9),(19,9),(18,20),(3,20)], True), L(3,9,19,9)],
"pin":       [P([(8.5,9.5),(15.5,9.5),(13.2,13.5),(10.8,13.5)], True), L(6,9.5,18,9.5), L(12,13.5,12,20.5)],
"bookmark":  [P([(6,3),(18,3),(18,21),(12,16),(6,21)], True)],
"archive":   [R(3,6,21,10,1), R(3,10,21,19,1), L(9,14,15,14)],
"more":      [C(6.5,12,1.6), C(12,12,1.6), C(17.5,12,1.6)],
}
CHAT = {
"attachment":[P([(16.5,6),(16.5,16.5),(13,20),(9.5,16.5),(9.5,7),(12,4.5),(13.5,6),(13.5,15)], False)],
"link":      [R(3,9.5,12.5,14.5,2.4), R(11.5,9.5,21,14.5,2.4)],
"quote":     [R(4,7,8,12,1), L(8,12,8,17), R(12,7,16,12,1), L(16,12,16,17)],
"copy":      [R(4,8,15,20,2), P([(8,8),(8,3.5),(20,3.5),(20,16),(15.5,16)])],
"retry":     [arcarrow(12,12,7,130,410)],
"edit":      [P([(4,20),(6,14),(17,3),(21,7),(10,18)], True)],
"branch":    [C(6,6,2.2), C(6,18,2.2), C(18,12,2.2), L(6,8.2,6,15.8), L(8.2,12,15.8,12)],
"send":      [FP([(3,12),(21,4),(14,20),(10.5,13)]), L(3,12,10.5,13)],
"stop":      [R(6,6,18,18,1, True)],
"chevron-down":[P([(6,9),(12,15),(18,9)])],
"chevron-right":[P([(9,6),(15,12),(9,18)])],
"plus":      [L(12,5,12,19), L(5,12,19,12)],
}
FILE = {
"file-text":   [P([(5,3),(14,3),(19,8),(19,21),(5,21)], True), L(14,3,14,8), L(14,8,19,8), L(8,12,16,12), L(8,16,16,16)],
"file-code":   [P([(5,3),(14,3),(19,8),(19,21),(5,21)], True), L(14,3,14,8), L(14,8,19,8), P([(10,11),(7,15),(10,19)]), P([(14,11),(17,15),(14,19)])],
"file-image":  [P([(5,3),(14,3),(19,8),(19,21),(5,21)], True), L(14,3,14,8), L(14,8,19,8), C(9.5,12,1.3), P([(6,18),(10,14),(13,17),(15.5,15),(18,18)])],
"file-table":  [P([(5,3),(14,3),(19,8),(19,21),(5,21)], True), L(14,3,14,8), L(14,8,19,8), L(5,13,19,13), L(12,13,12,21)],
"terminal":    [R(3,5,21,19,2), P([(7,10),(10,12.5),(7,15)]), L(11.5,15,16,15)],
"external":    [P([(7,7),(4,7),(4,20),(15,20),(15,17)]), L(11,13,20,4), P([(15,4),(20,4),(20,9)])],
}
STATUS = {
"check":  [P([(4,13),(9,18),(20,6)])],
"clock":  [C(12,12,8), L(12,12,12,6.5), L(12,12,16,14)],
"alert":  [P([(12,3),(21,20),(3,20)], True), L(12,8.5,12,14), C(12,17,1.1)],
"info":   [C(12,12,8), L(12,11,12,16.5), C(12,7.8,1.1)],
"play":   [FP([(8,4),(19,12),(8,20)])],
"pause":  [R(8,5,10.8,19,0, True), R(13.2,5,16,19,0, True)],
"close":  [L(6,6,18,18), L(18,6,6,18)],
}
SETTINGS = {
"settings":[C(12,12,4.2)] + [L(12 + 6.5*math.cos(math.radians(a)), 12 + 6.5*math.sin(math.radians(a)),
                                12 + 9*math.cos(math.radians(a)), 12 + 9*math.sin(math.radians(a))) for a in range(0,360,45)],
"sliders": [L(3,7,21,7), L(3,12,21,12), L(3,17,21,17), C(8,7,1.8), C(15,12,1.8), C(10,17,1.8)],
"sun":     [C(12,12,4.5)] + [L(12 + r1*math.cos(math.radians(a)), 12 + r1*math.sin(math.radians(a)),
                               12 + r2*math.cos(math.radians(a)), 12 + r2*math.sin(math.radians(a)))
                             for a, r1, r2 in [(a,6.8,9.5) for a in range(0,360,45)]],
"moon":    [A(12,12,8,8,45,315)],
"palette": [C(12,12,8), C(8,10,1.2), C(12,8.5,1.2), C(16,10,1.2), L(12,20,12,17)],
"companion":[C(12,12,7), P([(12,5.5),(18.5,12),(12,18.5),(5.5,12)], True)],
"volume":  [FP([(3,10),(6,10),(11,5),(11,19),(6,14),(3,14)]), A(11,12,4.6,4.6,-38,38), A(11,12,8,8,-30,30)],
"mute":    [FP([(3,10),(6,10),(11,5),(11,19),(6,14),(3,14)]), L(14,9,21,16), L(21,9,14,16)],
"download":[L(12,3,12,15), P([(7,10),(12,15),(17,10)]), P([(4,18),(4,20),(20,20),(20,18)])],
"shield":  [P([(12,3),(20,7),(20,13),(12,21),(4,13),(4,7)], True)],
"expand":  [P([(4,9),(4,4),(9,4)]), P([(15,4),(20,4),(20,9)]), P([(4,15),(4,20),(9,20)]), P([(20,15),(20,20),(15,20)])],
}
DSH = {
"plugin":  [R(4,4,20,20,1), C(20,10,2.2), C(12,4,2.2)],
"skill":   [R(4,4,20,20,2), P([(12,7),(14,11),(18,11),(15,14),(16,18),(12,16),(8,18),(9,14),(6,11),(10,11)], True)],
"model":   [P([(12,3),(20,8),(20,16),(12,21),(4,16),(4,8)], True), L(4,8,12,12), L(20,8,12,12), L(12,12,12,21)],
"agent":   [R(4,7,20,18,2), L(12,3,12,7), C(12,3,1.4), C(9,12,1.2), C(15,12,1.2), L(9,15.5,15,15.5)],
"question":[R(3,4,21,16,3), P([(8,16),(8,20),(12,16)]), P([(9.5,8.5),(12,6.5),(14.5,8.5),(14.5,10),(12,12),(12,13.2)]), C(12,15.5,1.0)],
"plan":    [R(4,3,20,21,2), L(11,8,17,8), L(11,13,17,13), L(11,18,17,18), P([(6.5,8),(7.5,9),(9,7)]), P([(6.5,13),(7.5,14),(9,12)]), P([(6.5,18),(7.5,19),(9,17)])],
"inbox":   [R(3,8,21,19,2), P([(3,13),(8,13),(10,16),(14,16),(16,13),(21,13)])],
"git-diff":[R(2,4,10.5,20,1.5), R(13.5,4,22,20,1.5), L(4.4,12,8.1,12), L(6.25,10.2,6.25,13.8), L(15.9,12,19.6,12)],
}

GROUPS = [("nav", NAV), ("chat", CHAT), ("file", FILE), ("status", STATUS), ("settings", SETTINGS), ("dsh", DSH)]
ALL = {}
for _, d in GROUPS: ALL.update(d)

# ---- SVG ----
def fmt(v):
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return s if s else "0"

def svg_path(icon_ops):
    parts = []
    for op in icon_ops:
        if op[0] == "line":
            _, x1, y1, x2, y2 = op
            parts.append(f"M{fmt(x1)} {fmt(y1)}L{fmt(x2)} {fmt(y2)}")
        elif op[0] == "poly":
            _, pts, closed = op
            d = "M" + " L".join(f"{fmt(x)} {fmt(y)}" for x, y in pts)
            parts.append(d + ("Z" if closed else ""))
        elif op[0] == "rect":
            _, x0, y0, x1, y1, r, fill = op
            parts.append(f"M{fmt(x0+r)} {fmt(y0)}H{fmt(x1-r)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x1)} {fmt(y0+r)}"
                         f"V{fmt(y1-r)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x1-r)} {fmt(y1)}H{fmt(x0+r)}"
                         f"A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x0)} {fmt(y1-r)}V{fmt(y0+r)}"
                         f"A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x0+r)} {fmt(y0)}Z")
        elif op[0] == "circle":
            _, cx, cy, r, fill = op
            parts.append(f"M{fmt(cx-r)} {fmt(cy)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(cx+r)} {fmt(cy)}"
                         f"A{fmt(r)} {fmt(r)} 0 0 1 {fmt(cx-r)} {fmt(cy)}Z")
        elif op[0] == "arc":
            _, cx, cy, rx, ry, s, e = op
            pts = arc_points(cx, cy, rx, ry, s, e)
            parts.append("M" + " L".join(f"{fmt(x)} {fmt(y)}" for x, y in pts))
        elif op[0] == "arcarrow":
            _, cx, cy, r, s0, e0 = op
            pts = arc_points(cx, cy, r, r, s0, e0)
            parts.append("M" + " L".join(f"{fmt(x)} {fmt(y)}" for x, y in pts))
            ex, ey = pts[-1][-1], pts[-1][-2] if False else pts[-1]
            ex, ey = pts[-1]
            a = math.radians(e0)
            tan = (-math.sin(a), math.cos(a))
            for off in (-2.4, 2.4):
                rot = math.radians(math.degrees(math.atan2(tan[1], tan[0])) - off)
                parts.append(f"M{fmt(ex)} {fmt(ey)}L{fmt(ex - 3*math.cos(rot))} {fmt(ey - 3*math.sin(rot))}")
        elif op[0] == "fillpoly":
            _, pts = op
            parts.append("M" + " L".join(f"{fmt(x)} {fmt(y)}" for x, y in pts) + "Z")
        else:
            raise ValueError(op)
    return " ".join(parts)

def build_svg(icon_ops, color_hex):
    d = svg_path(icon_ops)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" role="img">
  <title></title>
  <g fill="none" stroke="{color_hex}" stroke-width="{fmt(STROKE)}" stroke-linecap="round" stroke-linejoin="round">
    <path d="{d}"/>
  </g>
</svg>
"""

# ---- PNG ----
def render(icon_ops, color):
    S = SUPER
    img = Image.new("RGBA", (int(G * S),) * 2, (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    w = int(round(STROKE * S))
    def sc(pts): return [(x * S, y * S) for x, y in pts]
    col = color + (255,)
    for op in icon_ops:
        k = op[0]
        if k == "line":
            _, x1, y1, x2, y2 = op
            dr.line([(x1*S, y1*S), (x2*S, y2*S)], fill=col, width=w)
            for x, y in [(x1, y1), (x2, y2)]:
                dr.ellipse([x*S-w/2, y*S-w/2, x*S+w/2, y*S+w/2], fill=col)
        elif k == "poly":
            _, pts, closed = op
            sp = sc(pts)
            if closed: sp = sp + [sp[0]]
            dr.line(sp, fill=col, width=w, joint="curve")
            for x, y in sp:
                dr.ellipse([x-w/2, y-w/2, x+w/2, y+w/2], fill=col)
        elif k == "fillpoly":
            _, pts = op
            dr.polygon(sc(pts), fill=col)
        elif k == "rect":
            _, x0, y0, x1, y1, r, fill = op
            box = [x0*S, y0*S, x1*S, y1*S]
            if fill:
                dr.rounded_rectangle(box, radius=r*S, fill=col)
            else:
                dr.rounded_rectangle(box, radius=r*S, outline=col, width=w)
        elif k == "circle":
            _, cx, cy, r, fill = op
            box = [(cx-r)*S, (cy-r)*S, (cx+r)*S, (cy+r)*S]
            if fill: dr.ellipse(box, fill=col)
            else: dr.ellipse(box, outline=col, width=w)
        elif k == "arcarrow":
            _, cx, cy, r, s0, e0 = op
            pts = arc_points(cx, cy, r, r, s0, e0, step=7.0)
            dr.line(sc(pts), fill=col, width=w, joint="curve")
            ex, ey = pts[-1]
            a = math.radians(e0)
            tan = (-math.sin(a), math.cos(a))
            for off in (-2.4, 2.4):
                rot = math.radians(math.degrees(math.atan2(tan[1], tan[0])) - off)
                dr.line([(ex*S, ey*S), ((ex - 3*math.cos(rot))*S, (ey - 3*math.sin(rot))*S)], fill=col, width=w)
        elif k == "arc":
            _, cx, cy, rx, ry, s, e = op
            pts = arc_points(cx, cy, rx, ry, s, e, step=2.0)
            dr.line(sc(pts), fill=col, width=w, joint="curve")
            for x, y in [pts[0], pts[-1]]:
                dr.ellipse([x*S-w/2, y*S-w/2, x*S+w/2, y*S+w/2], fill=col)
        else:
            raise ValueError(op)
    return img.resize((OUT_PX, OUT_PX), Image.LANCZOS)

def hex2rgb(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

PALETTES = {
    "accent":  {"light": "#5B4FE3", "dark": "#9C8BFF", "light_dir": "exports/icons/light",         "dark_dir": "exports/icons/dark"},
    "neutral": {"light": "#4A5470", "dark": "#B9C4DE", "light_dir": "exports/icons/light-neutral", "dark_dir": "exports/icons/dark-neutral",
                "override": {"send": "#FFFFFF", "stop": "#FFFFFF"}},
}

def main(root, palette="accent"):
    cfg = PALETTES[palette]
    hexlight, hexdark = cfg["light"], cfg["dark"]
    override = cfg.get("override", {})
    svgdir = os.path.join(root, "source/icons")
    lightdir = os.path.join(root, cfg["light_dir"])
    darkdir = os.path.join(root, cfg["dark_dir"])
    for d in (svgdir, lightdir, darkdir): os.makedirs(d, exist_ok=True)
    old = os.path.join(root, "exports/icons/individual")
    if os.path.isdir(old): os.rename(old, os.path.join(root, "source/icons/_legacy-thematic-icons"))
    for name, ops in ALL.items():
        cl = override.get(name, hexlight)
        cd = override.get(name, hexdark)
        # 强调色一套才写 SVG 源（中性色由同一 SVG 换色复现）
        if palette == "accent":
            open(os.path.join(svgdir, f"{name}.svg"), "w", encoding="utf-8").write(build_svg(ops, hexlight))
        render(ops, hex2rgb(cl)).save(os.path.join(lightdir, f"{name}.png"))
        render(ops, hex2rgb(cd)).save(os.path.join(darkdir, f"{name}.png"))
    return len(ALL)

if __name__ == "__main__":
    import sys
    print("生成图标数:", main(sys.argv[1] if len(sys.argv) > 1 else ".", sys.argv[2] if len(sys.argv) > 2 else "accent"))
