# 功能图标系统（56 枚）

## 规格

| 项 | 值 |
|---|---|
| 数量 | 56 枚，覆盖文档《功能图标清单》导航／对话／文件／状态／设置／DSH 功能六组 |
| 矢量源 | `source/icons/<file-id>.svg`，24×24 画板，2px 线宽，圆头端点，`viewBox="0 0 24 24"` |
| 位图 | `exports/icons/light/<file-id>.png`、`exports/icons/dark/<file-id>.png`，各 56 张，共 112 张 |
| PNG 规格 | 96×96 px，sRGB，RGBA（透明底），非白底 |
| 浅色线条 | `#B52328`（`--accent` 浅色模式） |
| 深色线条 | `#E43B3B`（`--accent` 深色模式） |
| 索引 | `icons-index.csv`（编号／分组／名称／文件ID／矢量源／两版路径／尺寸） |
| 识别度 | `qa-16-20-24px.png`：全部 56 枚在 16／20／24 px 下的实际渲染排布 |

## 生成方式

56 个图标共用同一份几何定义（`/tmp/gen_icons.py` 为生成器，随包放在
`source/icons/_generator/gen_icons.py`），由同一份几何同时输出 SVG 与 96px PNG。
因此**矢量源与位图逐点对应**，任意放大不失真，线宽、圆角、光学居中全部一致。
不是 AI 位图，也不存在"位图描摹"的锯齿问题。

## 命名与目录

```
source/icons/
  send.svg  compose.svg  settings.svg  …（56 个）
  _generator/gen_icons.py          生成器（可改几何后一键重出全部规格）
  _legacy-thematic-icons/          旧题材图标（卡牌／龙鳞／雷光那套，已停用，仅留档）
  icon-set-overview-*.png          旧拼版与总览留档
exports/icons/
  light/<file-id>.png    56 张浅色
  dark/<file-id>.png     56 张深色
  icons-index.csv
  qa-16-20-24px.png
```

## 分组构成

| 分组 | 数量 | file id |
|---|---|---|
| 导航 | 12 | workspace · compose · conversation · history · search · panel-left · folder · folder-open · pin · bookmark · archive · more |
| 对话 | 12 | attachment · link · quote · copy · retry · edit · branch · send · stop · chevron-down · chevron-right · plus |
| 文件 | 6 | file-text · file-code · file-image · file-table · terminal · external |
| 状态 | 7 | check · clock · alert · info · play · pause · close |
| 设置 | 11 | settings · sliders · sun · moon · palette · companion · volume · mute · download · shield · expand |
| DSH 功能 | 8 | plugin · skill · model · agent · question · plan · inbox · git-diff |

## 易混组已做的区分

- **发送 vs 停止**：发送是倾斜纸飞机（实心面 + 折线），停止是实心方块，轮廓完全不同。
- **播放 vs 暂停**：三角形 vs 两根竖条。
- **声音 vs 静音**：扬声器两道声波 vs 扬声器 + 交叉线。
- **文件夹 vs 展开文件夹**：闭合矩形 + 页签 vs 上沿敞开的梯形。
- **展开 vs 进入**：向下／向右的独立尖括号；与 `expand`（四角外扩）也不重形。

## 已知限制

- 状态组的 7 枚图标在本套里是单色线条（跟随主题强调色）；带语义色的状态图（成功绿／警告橙／错误红）另出一套在 `exports/states/`。
- 图标本身不含发光效果；深色模式的 `--glow-accent` 需要由 CSS 或合成层加。
