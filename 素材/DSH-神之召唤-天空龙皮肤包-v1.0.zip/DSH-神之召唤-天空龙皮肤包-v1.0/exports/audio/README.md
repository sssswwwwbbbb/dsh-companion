# 音频资源说明

## 交付清单（8 个 WAV）

统一规格：**WAV / 48 kHz / 24 bit / 立体声 / 响度 −16 LUFS / 峰值 ≤ −1 dBFS**

| 文件 | 时长 | 触发时间码 | 内容 |
|---|---|---|---|
| `dsh_cube_hum.wav` | 1.8s | 00:00 | 千年积木低频共鸣，缓慢渐强 |
| `dsh_summon_lightning.wav` | 2.8s | 00:02 | 雷云汇聚、远处雷鸣与气流风压 |
| `dsh_jp_voice.wav` | 2.9s | 00:04 | 日语召唤台词「千年積木の名のもとに、神の龍を召喚する！」 |
| `dsh_dragon_roar.wav` | 1.8s | 00:06 | 神龙仰天长啸，低频咆哮带混响 |
| `dsh_red_flash_transition.wav` | 1.8s | 00:07 | 红光转场爆发冲击音 |
| `dsh_workspace_boot.wav` | 1.8s | 00:08 | 工作区界面启动提示音 |
| `dsh_main_theme_loop.wav` | 14.0s | 全程循环 | 决斗史诗氛围 BGM，首尾可循环 |
| `opening-final-mix.wav` | 10.0s | 00:00–00:10 | 上面 6 段按时间码合成的完整开场音轨 |

## 关于配音声线

`dsh_jp_voice.wav` 是 **原创少年决斗者声线**，不是原作动画声优的音色复刻。
按需求做的方向：音色偏亮偏高、少年感、气息足、字句顿挫有力、庄重带压迫感。
如果听感偏差，可以按这个方向调参数重生成（改语速、情绪强度、音高年龄段等），但真人声优的声纹本身不做克隆。

## 接入方式

- 直接替换 `opening-film.mp4` 内音轨：用 `opening-final-mix.wav` 对齐后混流。
- 单独挂音效：按上表时间码在动效时间轴上触发对应 WAV。
- BGM 循环：`dsh_main_theme_loop.wav` 首尾能量接近，可直接 loop。
