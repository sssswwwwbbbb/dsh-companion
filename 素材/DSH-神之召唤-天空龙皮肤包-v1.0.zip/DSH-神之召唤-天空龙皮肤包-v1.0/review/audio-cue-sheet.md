# 音频提示表（cue sheet）

全部文件 48 kHz / 24-bit WAV，立体声。音量统一 −16 LUFS（干声除外）。

## 台词

| 台词 ID | 时间码（开场内） | 文本（日） | 文本（中） | 文件 | 处理 |
|---|---|---|---|---|---|
| V01 | 00:04.00–00:07.00 | 千年積木の名のもとに、神の龍を召喚する！ | 以千年积木之名，召唤神之龙！ | `exports/audio/voice-line-01-jp-summon_dry.wav` | **无处理干声**（未归一化，仅统一到 48kHz/24bit） |
| V01（成片用） | 同上 | — | — | `exports/audio/dsh_jp_voice.wav` | 已降噪 + −16 LUFS，用于成片 |

声线说明：原创少年决斗者声线（偏亮偏高、气息足、顿挫有力），不是原作动画声优的音色复刻。

## 音乐与环境

| 文件 | 用途 | 起止 | 循环点 |
|---|---|---|---|
| `dsh_main_theme_loop.wav` | 开场 BGM | 00:00–00:10（成片内） | 0 / 14.0s 首尾对齐，可整段循环 |
| `dsh_cube_hum.wav` | 千年积木共鸣 | 00:00.0 | 否 |
| `dsh_summon_lightning.wav` | 雷云与召唤雷击（含远雷） | 00:04.0 | 否 |
| `dsh_dragon_roar.wav` | 龙啸 | 00:07.0 | 否 |
| `dsh_red_flash_transition.wav` | 红光转场 | 00:08.0 | 否 |
| `dsh_workspace_boot.wav` | 工作区上电落点 | 00:08.5 | 否 |

## 分轨

| 文件 | 内容 | 说明 |
|---|---|---|
| `opening-stem-voice.wav` | 仅配音 | 10.0s，V01 置于 4.0s |
| `opening-stem-bgm.wav` | 仅 BGM | 10.0s，`dsh_main_theme_loop` 前 10s |
| `opening-stem-sfx.wav | 仅音效 | 5 条音效按上表时间码叠加 |
| `opening-final-mix.wav` | 最终混音 | **由三条分轨合成**：voice 1.0 + sfx 1.0 + bgm 0.55，淡入淡出 0.4s，−16 LUFS，峰值 −1.89 dBFS |
| `opening-final-mix-v1-art.wav` | 上一版母版 | 留档，不作为分轨拆解依据 |

> 分轨与 `opening-final-mix.wav` 严格一致（mux 关系可复算）；与 `opening-final-mix-v1-art.wav` 存在增益与叠加差异，属两版混音，不是同一母版的拆解。

## 未交付（选做项）

界面提示音：成功、需处理、操作彩蛋、专注计时提醒。本套未生成，接入时按事件补 60–120ms 短音即可。
