# 开场分镜表 · 神之召唤

片长 10.0s（实测 10.08s），1280×720，16:9，24fps。片尾停在红光溶解、切入深色工作区的瞬间，能直接接回工作区。

| 镜号 | 时间码 | 段落 | 画面 | 动效 | 音频 | 交付帧 |
|---|---|---|---|---|---|---|
| S1 | 00:00–00:02 | 起始 | 千年积木悬在暗场中，金色符文逐格点亮 | 发光层渐亮 + 8 帧内完成符文点亮 | `dsh_cube_hum` 渐入 | `opening/frame-01-cube-glow.png` |
| S2 | 00:02–00:04 | 起始→推进 | 镜头后拉，亚图姆背影进入画面，雷云汇聚 | 三层视差（人物／云／雷） | 风压与远雷（合在 `dsh_summon_lightning` 内） | — |
| S3 | 00:04–00:07 | 主视觉 | 天空龙破云而出，双翼展开，巨爪前探 | 翼膜依次展开 + 雷光沿身体流动（6 帧循环） | `dsh_jp_voice` + `dsh_summon_lightning` | `opening/frame-02-summon-burst.png` |
| S4 | 00:07–00:08 | 主视觉高潮 | 仰天长啸，红光扫过全屏 | 全屏红闪 + 镜头震动 ±6px | `dsh_dragon_roar` | `opening/opening-still-1280x720.png`（定格点） |
| S5 | 00:08–00:10 | 结束 | 红光溶解，切入 DSH 深色工作区 | 遮罩溶解 + UI 组件分层上浮 | `dsh_red_flash_transition` → `dsh_workspace_boot` | `opening/frame-03-red-flash.png` |

## 落点与接续

- 结束帧亮度已压到与 `--bg-base`（深色 `#1A1230`）接近，切入工作区不出现亮度跳变。
- 跳过后落点：直接落在 S5 结束帧的静态工作区；对应静帧用 `opening/opening-still-1280x720.png`，不需要重新定位。
- 静态替代：无动效环境直接用 `opening-still-1280x720.png` 作为首屏图，5 段动效全部省略，音频可只留 `dsh_workspace_boot`。
- 静音表现：`exports/video/opening-film-mute.mp4` 为去音轨版本，画面一致；或整段静音播放 `opening-film.mp4`。
