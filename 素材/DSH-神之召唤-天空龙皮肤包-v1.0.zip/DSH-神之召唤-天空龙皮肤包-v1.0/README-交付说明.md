# DSH 皮肤 · 神之召唤 · 天空龙

交付包：**DSH-神之召唤-天空龙皮肤包-v1.0**。自用二创素材，不商用。

## 1. 一眼看到什么

- 主视觉与开场：10 秒日语开场片（`exports/video/opening-film.mp4`）、去音轨版、4 张关键帧、主视觉与封面。
- 视觉规范：色值、字族、间距、圆角、动效手册（`review/`）。
- 图标系统：**56 枚功能图标 × 视频（浅/深）两套**，矢量源 + 96×96 透明 PNG 全给。
- 状态与小操作：6 态 × 浅深两套状态图、3 个操作图标、入口标识与头像。
- 音频：开场 5 段音效 + BGM + 配音 + 分轨 + 合成母版（48 kHz / 24-bit）。
- 待机与页面：聊天背景、叠加效果图、待机短循环静帧。

## 2. 目录树

```
DSH-神之召唤-天空龙皮肤包-v1.0/
├── README-交付说明.md          ← 本文件
├── copy/                       文案：开场台词 SRT、角色语气说明、主题元信息
├── exports/
│   ├── icons/light|dark/       56 + 56 张 96×96 RGBA；icons-index.csv；qa-16-20-24px.png
│   ├── icons/README.md         图标规格、分组、易混组区分、生成方式
│   ├── states/                 6 态 × 浅深 = 12 张 96×96 RGBA（+4 张插画变体）
│   ├── actions/                新建会话 / 发送 / 复制成功，96×96 RGBA
│   ├── brand/                  入口标识（六角徽记）浅深两版 96×96 RGBA + 插画变体
│   ├── avatar-256x256*.png     头像（白底版 + 透明版）
│   ├── audio/                  8 条基础音频 + 干声 + 3 轨分轨 + 母版
│   ├── video/                  opening-film.mp4（含配音）、opening-film-mute.mp4（静音）
│   ├── opening/                4 张关键帧（00:07 定格）
│   ├── key-art/ covers/ art/   主视觉、封面、插画
│   ├── backgrounds/            chat-bg 1440×900（png/webp）+ in-context 效果图
│   └── idle/                   idle-loop-still-512x512.png
├── review/
│   ├── color-spec.md           色值与字体规范
│   ├── animation-dev-manual.md 动效手册（时间码、缓动、帧预算）
│   ├── opening-storyboard.md   开场分镜表（起始／主视觉／结束三段）
│   ├── status-copy.md          6 态短文案 + 三态小操作 + 静音表现
│   ├── idle-loop-spec.md       待机短循环：时长、循环点、终态、静态替代
│   ├── audio-cue-sheet.md      音频提示表与分轨说明
│   ├── asset-manifest.csv      台账：每件一行，含文件ID/规格/授权/交付状态
│   └── style-compare.png       风格对齐对照
├── source/icons/               56 个 SVG（24×24 画板）+ 生成器 + 旧题材图标留档
├── source/art/                 源素材
└── licenses/license-record.md  授权与来源记录
```

## 3. 图标系统（与《交付清单》对齐）

| 项 | 文档要求 | 本包交付 |
|---|---|---|
| 数量 | 56 个固定 file-id | **56 个**，id 与文档清单逐字一致 |
| 矢量 | 24×24 SVG / 2px 线性 | 56 个 SVG，`viewBox 0 0 24 24` |
| 位图 | 96×96 PNG，浅深各一 | 浅 56 + 深 56 = **112 张** |
| 透明底 | 必须透明 | 全部 RGBA，无白底 |
| 命名 | 按 file-id | `send.svg` / `light/send.png` / `dark/send.png` |

分组：导航 12 / 对话 12 / 文件 6 / 状态 7 / 设置 11 / DSH 功能 8。
生成器 `source/icons/_generator/gen_icons.py` 可从同一份几何一键重出全部规格（改线条即改全部）。

## 4. 音频

| 文件 | 时长 | 用途 |
|---|---|---|
| `dsh_cube_hum.wav` | 1.80s | 千年积木共鸣 |
| `dsh_summon_lightning.wav` | 2.80s | 雷云与召唤 |
| `dsh_jp_voice.wav` | 2.90s | 日语台词（成片用） |
| `voice-line-01-jp-summon_dry.wav` | 3.00s | **干声**，未做归一，供二次处理 |
| `dsh_dragon_roar.wav` | 1.80s | 龙啸 |
| `dsh_red_flash_transition.wav` | 1.79s | 红光转场 |
| `dsh_workspace_boot.wav` | 1.79s | 工作区上电 |
| `dsh_main_theme_loop.wav` | 14.00s | BGM，首尾可循环 |
| `opening-stem-voice/bgm/sfx.wav` | 10.00s ×3 | 分轨 |
| `opening-final-mix.wav` | 10.00s | 母版（由三轨合成，−16 LUFS） |
| `opening-final-mix-v1-art.wav` | 10.00s | 上一版母版，留档 |

## 5. 与文档清单的偏差（如实说明）

1. **配音声线**：原创少年决斗者声线（偏亮偏高、气息足），**没有**复刻原作动画声优的音色与声纹；台词文本与断句按 `copy/opening-script.srt`。
2. **界面提示音**（成功／需处理／彩蛋／专注计时）4 类：**未交付**，属文档选做项；状态表已标注"未单独交付"。
3. **动效文件**：只交静帧、帧序列与参数手册，没有导出 Lottie／CSS／AE 工程；待机与状态动效按 `review/idle-loop-spec.md`、`review/status-copy.md` 的参数在接入端实现。
4. **图标不再是题材卡牌位图**：旧的 36 枚卡牌题材图标已停用，移到 `source/icons/_legacy-thematic-icons/` 仅作留档；主交付是新的 56 枚线性矢量集。
5. **插画变体**：入口标识／操作／状态图标各有一份 `-art.png`（AI 插画风、带云纹底、不透明），可作大尺寸场景图，不作为界面主图标。
6. **分轨口径**：`opening-final-mix.wav` 与三条分轨严格一致；`opening-final-mix-v1-art.wav` 是更早的混音版本，二者不是同一母版的逐轨拆解。

## 6. 使用建议

- 浅色界面：图标取 `exports/icons/light/`，强调色 `#B52328`，背景 `#F5F0E1`。
- 深色界面：图标取 `exports/icons/dark/`，强调色 `#E43B3B`，背景 `#1A1230`。
- 开场：`opening-film.mp4` 直接作为启动动画；不支持音频时换 `opening-film-mute.mp4`。
- 跳过后落点：`exports/opening/frame-03-red-flash.png`（切工作区那一帧），不需要额外素材。

台账逐件明细见 `review/asset-manifest.csv`。
